<?php
session_start();
if($_SESSION['sss']['id'] != 1){
    header('Location: index.php');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Админская страница, не лезь, убьёт</title>
</head>
<body>
    <?php
    require_once 'vender/connect.php';
    $check_users = mysqli_query($connect, "SELECT * FROM `sss`");
    $sss = mysqli_fetch_all($check_users);
    foreach ($sss as $value){
        echo '<br>';
        foreach ($value as $key => $item){
            echo $item.' | ';
        }
        echo '<br>';
    }
    ?>
    <a href="vender/logout.php" class="logout">Выход</a>
</body>
</html>
