<?php

$connect = mysqli_connect('localhost', 'root', '','sss');
if (!$connect) {
    die('Error connect to DB!!!');
}