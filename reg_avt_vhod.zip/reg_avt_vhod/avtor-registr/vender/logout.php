<?php
session_start();
unset($_SESSION['sss']);
header('Location: ../index.php');