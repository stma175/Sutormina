<?php
session_start();

require_once 'connect.php';

$login = $_POST['login'];
$password = md5($_POST['password']);

$check_sss = mysqli_query($connect, "SELECT * FROM `sss` WHERE `login` = '$login' AND `password` = '$password'");
$sss = mysqli_fetch_assoc($check_sss);
if ( mysqli_num_rows($check_sss) > 0) {
    $_SESSION['sss'] = [
        'id' => $sss['id'],
        'full_name' => $sss['full_name'],
        'login' => $sss['login'],
        'email' => $sss['email'],
        'avatar' => $sss['avatar']
    ];
    header('Location: ../profile.php');
} else {
    $_SESSION['massage'] = 'Неверный Логин или Пароль!!!';
    header('Location: ../index.php');
}