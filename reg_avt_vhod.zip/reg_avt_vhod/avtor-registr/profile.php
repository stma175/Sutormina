<?php
session_start();
if(!isset($_SESSION['sss'])){
    header('Location: index.php');
}
if($_SESSION['sss']['id'] == 1){
    header('Location: admin.php');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Профиль</title>
</head>
<body>
<form>
    <img src="<?php
    if(empty($_SESSION['sss']['avatar'])){
        echo 'uploads/Без имени.png';
    } else {echo $_SESSION['sss']['avatar'];}
    ?>" width="200px" alt="Нет аватара">
    <h1 style="margin: 10px"><?= $_SESSION['sss']['full_name'] ?></h1>
    <a href="#"><?= $_SESSION['sss']['email'] ?></a>
    <a href="vender/logout.php" class="logout">Выход</a>
</form>
</body>
</html>
